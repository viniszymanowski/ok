// Funções JavaScript para o sistema de controle de manutenção

// Função para confirmar exclusão
function confirmarExclusao(mensagem, url) {
    if (confirm(mensagem)) {
        window.location.href = url;
    }
}

// Função para adicionar campos de peças dinamicamente
function adicionarCampoPeca() {
    const container = document.getElementById('pecas-container');
    const novoCampo = document.createElement('div');
    novoCampo.className = 'row mb-3 peca-item';
    
    const index = document.querySelectorAll('.peca-item').length;
    
    novoCampo.innerHTML = `
        <div class="col-md-5">
            <input type="text" class="form-control" name="peca_nome" placeholder="Nome da peça" required>
        </div>
        <div class="col-md-3">
            <input type="number" class="form-control" name="peca_quantidade" placeholder="Quantidade" min="1" value="1" required>
        </div>
        <div class="col-md-3">
            <input type="number" class="form-control" name="peca_valor" placeholder="Valor unitário" step="0.01" min="0" required>
        </div>
        <div class="col-md-1">
            <button type="button" class="btn btn-danger btn-sm" onclick="removerCampoPeca(this)">
                <i class="fas fa-trash"></i>
            </button>
        </div>
    `;
    
    container.appendChild(novoCampo);
}

// Função para remover campo de peça
function removerCampoPeca(botao) {
    const campo = botao.closest('.peca-item');
    campo.remove();
}

// Função para calcular próxima manutenção preventiva
function calcularProximaManutencao(horimetroAtual, intervaloHoras) {
    const proximaManutencao = parseFloat(horimetroAtual) + parseFloat(intervaloHoras);
    document.getElementById('proxima_manutencao').value = proximaManutencao.toFixed(2);
}

// Função para atualizar campos de horímetro
function atualizarHorimetro(colheitadeiraId) {
    fetch(`/api/colheitadeiras/${colheitadeiraId}`)
        .then(response => response.json())
        .then(data => {
            document.getElementById('horimetro_na_manutencao').value = data.horimetro_atual;
            document.getElementById('horas_motor_na_manutencao').value = data.horas_motor_atual;
        })
        .catch(error => console.error('Erro ao buscar dados da colheitadeira:', error));
}

// Função para gerar gráfico de custos
function gerarGraficoCustos(dados) {
    const ctx = document.getElementById('grafico-custos').getContext('2d');
    
    new Chart(ctx, {
        type: 'pie',
        data: {
            labels: ['Manutenções Preventivas', 'Manutenções Corretivas'],
            datasets: [{
                data: [dados.custo_preventivas, dados.custo_corretivas],
                backgroundColor: ['#27ae60', '#e74c3c'],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            legend: {
                position: 'bottom'
            }
        }
    });
}

// Função para gerar gráfico de manutenções
function gerarGraficoManutencoes(dados) {
    const ctx = document.getElementById('grafico-manutencoes').getContext('2d');
    
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: dados.meses,
            datasets: [
                {
                    label: 'Preventivas',
                    data: dados.preventivas,
                    backgroundColor: '#27ae60',
                    borderWidth: 1
                },
                {
                    label: 'Corretivas',
                    data: dados.corretivas,
                    backgroundColor: '#e74c3c',
                    borderWidth: 1
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                yAxes: [{
                    ticks: {
                        beginAtZero: true
                    }
                }]
            }
        }
    });
}

// Inicialização quando o documento estiver pronto
document.addEventListener('DOMContentLoaded', function() {
    // Inicializar tooltips do Bootstrap
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Inicializar datepickers
    const datepickers = document.querySelectorAll('.datepicker');
    if (datepickers.length > 0) {
        datepickers.forEach(function(el) {
            new Pikaday({
                field: el,
                format: 'YYYY-MM-DD'
            });
        });
    }
    
    // Inicializar select2 para melhorar selects
    const selects = document.querySelectorAll('select');
    if (selects.length > 0 && typeof $.fn.select2 !== 'undefined') {
        $(selects).select2({
            theme: 'bootstrap4'
        });
    }
});
