import os
import sys
import logging
from flask import Flask, render_template, redirect, url_for, flash, request
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
import datetime

# Configurar logging detalhado
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s [%(levelname)s] %(message)s',
    handlers=[logging.StreamHandler(sys.stdout)]
)
logger = logging.getLogger(__name__)

# Função para inicializar o banco de dados
def init_db():
    try:
        from models import db, Usuario, Colheitadeira, ManutencaoPreventiva, ManutencaoCorretiva, TrocaOleo, RegistroHorimetro, ItemEstoque, MovimentacaoEstoque
        
        # Criar todas as tabelas
        db.create_all()
        logger.info("Tabelas do banco de dados criadas com sucesso")
        
        # Verificar se já existe um usuário admin
        admin = Usuario.query.filter_by(username='admin').first()
        if not admin:
            # Criar usuário admin padrão
            admin = Usuario(username='admin', nome='Administrador', email='admin@example.com')
            admin.set_password('admin123')
            db.session.add(admin)
            db.session.commit()
            logger.info("Usuário admin criado com sucesso")
            
        # Verificar se existem dados de exemplo
        if Colheitadeira.query.count() == 0:
            # Adicionar uma colheitadeira de exemplo
            colheitadeira = Colheitadeira(
                modelo='John Deere S550',
                ano=2023,
                numero_frota='JD001',
                status='Ativa'
            )
            db.session.add(colheitadeira)
            
            # Adicionar um item de estoque de exemplo
            item = ItemEstoque(
                codigo='F001',
                nome='Filtro de Óleo John Deere',
                categoria='Filtros',
                quantidade=10,
                unidade='Unidade',
                valor_unitario=150.00,
                estoque_minimo=3,
                localizacao='Prateleira A1',
                fornecedor='John Deere Peças',
                data_ultima_compra=datetime.datetime.now(),
                descricao='Filtro de óleo original para colheitadeiras John Deere série S'
            )
            db.session.add(item)
            
            db.session.commit()
            logger.info("Dados de exemplo adicionados com sucesso")
            
    except Exception as e:
        logger.error(f"Erro ao inicializar banco de dados: {str(e)}")
        raise

if __name__ == '__main__':
    # Criar aplicação Flask
    app = Flask(__name__)
    
    # Carregar configurações
    from config import Config
    app.config.from_object(Config)
    
    # Inicializar o banco de dados
    from models import db
    db.init_app(app)
    
    with app.app_context():
        init_db()
        
    logger.info("Banco de dados inicializado com sucesso")
